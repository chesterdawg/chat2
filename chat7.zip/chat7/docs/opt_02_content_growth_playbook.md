# opt_02_content_growth_playbook.md

> Sprint: **S7 — Optimisation & Scale (Optional)** | Task: **S7-02 — Content breadth & quality sampling cadence**  
> Status: scaffold only — content to be authored in this sprint’s build pass

## What
(Describe in plain English what this task achieves.)

## Why
(Business value and technical stability it provides.)

## How
(Step-by-step instructions with copy/paste commands.)
1. 
2. 
3. 

## Verify
(Checks to prove it worked. What to run, what to see.)

## Troubleshoot
(Common issues and fixes.)

## Paired JSONs
- `configs/content/quality.sampling.json`

## Acceptance Criteria
- [ ] Document sections completed
- [ ] Steps verified end-to-end
- [ ] JSON files referenced exist and validate
