# ops_02_monitoring_and_perf.md

> Sprint: **S4 — Multi-Tenant & Security Hardening** | Task: **S4-04 — Monitoring: Sentry + pino + perf budgets**  
> Status: scaffold only — content to be authored in this sprint’s build pass

## What
(Describe in plain English what this task achieves.)

## Why
(Business value and technical stability it provides.)

## How
(Step-by-step instructions with copy/paste commands.)
1. 
2. 
3. 

## Verify
(Checks to prove it worked. What to run, what to see.)

## Troubleshoot
(Common issues and fixes.)

## Paired JSONs
- `configs/observability/monitoring.config.json`
- `configs/perf/budgets.json`

## Acceptance Criteria
- [ ] Document sections completed
- [ ] Steps verified end-to-end
- [ ] JSON files referenced exist and validate
