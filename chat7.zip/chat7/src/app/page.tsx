export default function Page() {
  return <main><h1>NDIS Support Chatbot</h1></main>;
}
